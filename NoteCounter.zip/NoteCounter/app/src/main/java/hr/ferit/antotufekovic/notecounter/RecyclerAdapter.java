package hr.ferit.antotufekovic.notecounter;

import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class RecyclerAdapter extends RecyclerView.Adapter<NameViewHolder> {

    private List<Entry> dataList = new ArrayList<>();

    private NameClickInterface clickInterface;

    public RecyclerAdapter(NameClickInterface clickInterface) {
        this.clickInterface = clickInterface;
    }

    @NonNull
    @Override
    public NameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_name, parent, false);
        return new NameViewHolder(view, clickInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull NameViewHolder nameViewHolder, int position) {
        if(dataList!=null)
        {
            nameViewHolder.setName(dataList.get(position).getName());
            nameViewHolder.setCount(dataList.get(position).getCount());
        }
        else
        {
            nameViewHolder.setName("oops");
            nameViewHolder.setCount(404);
        }
    }

    @Override
    public int getItemCount() {
        if (dataList!=null)
            return dataList.size();
        else
            return 0;
    }

    public void addData(List<Entry> data) {
        this.dataList.clear();
        this.dataList.addAll(data);
        notifyDataSetChanged();
    }

    public void setEntries(List<Entry> entries)//alias name wrapper
    {
        addData(entries);
    }

    public List<Entry> getData()
    {
        return dataList;
    }

    public void insertNewItem(String name,int count, int position) {
        if (position >= 0 && position <= dataList.size()) {
            dataList.add(position, new Entry(name,count));
            notifyItemInserted(position);
        }
    }
    public void insertNewItem(Entry unit, int position)
    {
        if (position >= 0 && position <= dataList.size()) {
            dataList.add(position, unit);
            notifyItemInserted(position);
        }
    }
    public void changeItem(Entry unit, int position)
    {
        if(dataList.size()<position+1)
            return;
        else
        {
            dataList.set(position,unit);
        }
    }

    public void removeItem(int position) {
        if (position >= 0 && position < dataList.size()) {
            dataList.remove(position);
            notifyItemRemoved(position);
        }
    }
}
